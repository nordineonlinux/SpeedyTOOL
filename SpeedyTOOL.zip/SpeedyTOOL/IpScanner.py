import socket
import time
from rich.console import Console
from rich.prompt import Prompt, IntPrompt
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TimeElapsedColumn
import pyfiglet

console = Console()

def banner():
    ascii_banner = pyfiglet.figlet_format("Port Scanner", font="slant")
    console.print(Panel(ascii_banner, title="[cyan]Network Tool[/cyan]", border_style="bright_red"))

def scan_ports(ip, start_port, end_port):
    console.print(Panel.fit(f"[bold yellow]Scanning {ip} from port {start_port} to {end_port}...[/bold yellow]"))

    open_ports = []

    with Progress(
        SpinnerColumn(),
        "[progress.description]{task.description}",
        TimeElapsedColumn(),
        transient=True
    ) as progress:
        task = progress.add_task("[green]Scanning ports...", total=end_port - start_port + 1)

        for port in range(start_port, end_port + 1):
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                    sock.settimeout(0.5)
                    result = sock.connect_ex((ip, port))
                    if result == 0:
                        open_ports.append(port)
                        console.print(f"[bold green][+][/bold green] Open port: {port}")
            except Exception as e:
                console.print(f"[red]Error on port {port}:[/red] {e}")
            finally:
                progress.update(task, advance=1)

    if open_ports:
        ports = ", ".join(str(p) for p in open_ports)
        console.print(Panel.fit(f"[bold green]Open ports found:[/bold green] {ports}"))
    else:
        console.print(Panel.fit("[bold red]No open ports detected.[/bold red]"))

def port_scanner_interface():
    banner()
    ip = Prompt.ask("[bold]Enter the IP to scan[/bold]")
    start_port = IntPrompt.ask("[bold]Start port[/bold]", default=1)
    end_port = IntPrompt.ask("[bold]End port[/bold]", default=1024)

    if start_port < 0 or end_port > 65535 or start_port > end_port:
        console.print("[red]Invalid port range.[/red]")
        return

    scan_ports(ip, start_port, end_port)

if __name__ == "__main__":
    port_scanner_interface()

