
import random
import string
import time
from rich.console import Console
from rich.prompt import IntPrompt, Prompt
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TimeElapsedColumn
import pyfiglet

console = Console()

def banner():
    ascii_banner = pyfiglet.figlet_format("Password Generator", font="slant")
    console.print(Panel(ascii_banner, title="[cyan]Secure & Random[/cyan]", border_style="bright_yellow"))

def generate_password(length, use_upper, use_digits, use_specials):
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase if use_upper else ""
    digits = string.digits if use_digits else ""
    specials = string.punctuation if use_specials else ""

    all_chars = lowercase + uppercase + digits + specials

    if not all_chars:
        console.print("[red]You must choose at least one character type.[/red]")
        return

    password = ""
    with Progress(
        SpinnerColumn(),
        "[progress.description]{task.description}",
        TimeElapsedColumn(),
        transient=True
    ) as progress:
        task = progress.add_task("[green]Generating password...", total=length)
        for i in range(length):
            password += random.choice(all_chars)
            console.print(f"[cyan][{i+1}/{length}][/cyan] [white]{password}[/white]")
            progress.update(task, advance=1)
            time.sleep(0.2)

    console.print(Panel.fit(f"[bold green]Generated Password:[/bold green] [white]{password}[/white]"))

def password_generator_interface():
    banner()
    length = IntPrompt.ask("[bold]Enter password length[/bold]", default=12)

    if length < 6:
        console.print("[red]Password too short. Minimum 6 characters.[/red]")
        return

    use_upper = Prompt.ask("[bold]Include uppercase letters?[/bold] (y/n)", default="y").lower() == "y"
    use_digits = Prompt.ask("[bold]Include digits?[/bold] (y/n)", default="y").lower() == "y"
    use_specials = Prompt.ask("[bold]Include special characters?[/bold] (y/n)", default="y").lower() == "y"

    console.print("\n[bold yellow]Preparing your password...[/bold yellow]")
    time.sleep(0.5)
    generate_password(length, use_upper, use_digits, use_specials)

if __name__ == "__main__":
    password_generator_interface()
