import random
import time
from rich.console import Console
from rich.prompt import IntPrompt
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TimeElapsedColumn
import pyfiglet

console = Console()

def banner():
    ascii_banner = pyfiglet.figlet_format("IP Generator V2", font="slant")
    console.print(Panel(ascii_banner, title="[cyan]Welcome[/cyan]", border_style="bright_blue"))

def generate_ips(count):
    console.print(Panel.fit(f"[bold yellow]Generating {count} random IP addresses...[/bold yellow]"))
    
    with Progress(
        SpinnerColumn(),
        "[progress.description]{task.description}",
        TimeElapsedColumn(),
        transient=True
    ) as progress:
        task = progress.add_task("[green]Generating IPs...", total=count)
        for i in range(count):
            a, b, c, d = (random.randint(0, 255) for _ in range(4))
            console.print(f"[bold cyan][{i+1}/{count}][/bold cyan] [white]{a}.{b}.{c}.{d}[/white]")
            progress.update(task, advance=1)
            time.sleep(0.4)

    console.print(Panel.fit("[bold green]Generation complete![/bold green]"))

def ip_generator_interface():
    banner()
    try:
        count = IntPrompt.ask("[bold]How many IPs do you want?[/bold]", default=10)
        generate_ips(count)
    except KeyboardInterrupt:
        console.print("\n[red]Cancelled by user.[/red]")

if __name__ == "__main__":
    ip_generator_interface()

    
        

    