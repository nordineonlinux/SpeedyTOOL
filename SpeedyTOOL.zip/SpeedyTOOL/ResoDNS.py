import socket
import time
from rich.console import Console
from rich.prompt import IntPrompt, Prompt
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TimeElapsedColumn
import pyfiglet

console = Console()

def banner():
    ascii_banner = pyfiglet.figlet_format("DNS Resolver", font="slant")
    console.print(Panel(ascii_banner, title="[cyan]OSINT Tool[/cyan]", border_style="bright_blue"))

def resolve_domains(domains):
    console.print("\n[bold yellow]Resolving domains...[/bold yellow]\n")
    time.sleep(1)

    with Progress(
        SpinnerColumn(),
        "[progress.description]{task.description}",
        TimeElapsedColumn(),
        transient=True
    ) as progress:
        task = progress.add_task("[green]DNS lookups...", total=len(domains))

        for idx, domain in enumerate(domains, start=1):
            console.print(f"[cyan][{idx}/{len(domains)}][/cyan] Resolving [white]{domain}[/white]...")
            time.sleep(0.8)
            try:
                ip = socket.gethostbyname(domain)
                console.print(f"   [bold green]IP found:[/bold green] {ip}\n")
            except socket.gaierror:
                console.print(f"   [bold red]Invalid domain[/bold red]\n")
            progress.update(task, advance=1)
            time.sleep(0.4)

    console.print(Panel.fit("[bold green]Resolution complete![/bold green]"))

def dns_resolver_interface():
    banner()
    try:
        count = IntPrompt.ask("[bold]How many domains do you want to resolve?[/bold] (1-20)", default=3)
    except KeyboardInterrupt:
        console.print("\n[red]Operation cancelled by user.[/red]")
        return

    if count < 1 or count > 20:
        console.print("[red]Invalid number of domains. Please choose between 1 and 20.[/red]")
        return

    domains = []
    for i in range(count):
        domain = Prompt.ask(f"[bold]Domain #{i+1}[/bold] (ex: xxxx.com)")
        domains.append(domain.strip())

    resolve_domains(domains)

if __name__ == "__main__":
    dns_resolver_interface()
